﻿using system;

public class TransacaoTed : Transacao
{
    public string Finalidade { get; set; }

    public override bool Validar()
    {
        // TED deve ser maior que 5.000 para fiscalização
        return _valor > 5000;
    }
}