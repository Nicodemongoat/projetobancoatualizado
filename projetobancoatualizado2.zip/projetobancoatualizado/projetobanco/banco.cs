﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    namespace projetobanco
    {
        public class Banco
        {
            public string Nome { get; set; }
            public string CodigoBACEN { get; set; }
        }
    }


